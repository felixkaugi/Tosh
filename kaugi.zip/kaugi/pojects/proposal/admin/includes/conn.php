<?php
$mysqli =new mysqli('localhost','root','','kenya_courts');
?>