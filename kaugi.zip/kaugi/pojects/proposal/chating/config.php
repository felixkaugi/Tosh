<?php

$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='';
$dbDatabase ='messages';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);

?>