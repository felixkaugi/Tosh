<?php include "layouts/header.php"; ?>
<div class="container">

<center><h2 style="color:white; margin-top:20%">Welcome digital judicial system chat session.</h2></center>
</div>

</body>
</html>
