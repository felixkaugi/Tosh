<?php 

$conn= new mysqli('localhost','root','','kenya_courts')or die("Could not connect to mysql".mysqli_error($con));
