<?php 
 session_start();
 //connecting to the database
 $con = mysqli_connect('localhost', 'root', '', 'myblog');
  if (!$con) {
  	die('failed to connect please' .mysqli_connect_error());
  }
 
 define ('ROOT_PATH', realpath(dirname(__FILE__)));
	define('BASE_URL', 'http://localhost/blog/');

 ?>

