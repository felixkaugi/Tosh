<?php include ('/includes/functions.php'); ?>
<!-- retriving all the posts fom the database -->
<?php $post= getPublishedPost(); ?>

<?php //include 'config.php';
$con = mysqli_connect('localhost','root','','myblog');
 ?>
<?php include(ROOT_PATH. '/includes/head_session.php'); ?>
	<title>Blog | Home </title>
	</head>
<body>
	 <div class="container">
	 	<div class="col">
	 		<!--navbar -->
	 		<?php include (ROOT_PATH. '/includes/navbar.php'); ?>
	 		<!-- banner -->
	 		<?php include (ROOT_PATH. '/includes/banner.php') ; ?>
	 	<div class="content">
	 		<!-- more details to come here -->
	 		<h2 class="content-title">Recent articles</h2>
	 		<hr>
	 		<?php foreach ($post as $posts):?>
	 			<div class="post" style="margin-left: 0px;">
	 				<img src="<?php echo BASE_URL . '/static/images/kaugi.PNG' . $post['image']; ?>" class="post_image" alt="">
	 				<!--getting post topics -->
	 				<?php if (isset($posts['topic']['name'])): ?>
			<a 
				href="<?php echo BASE_URL . 'filtered_posts.php?topic=' . $post['topic']['id'] ?>"
				class="btn category">
				<?php echo $posts['topic']['name'] ?>
			</a>
		<?php endif ?>
           <!-- getting post topics ends here -->
	 				<a href="post.php?post-slug=<?php echo $post['slug']; ?>">
	 					<div class="post_info">
	 						<h3><?php echo $posts['title'] ?></h3>
	 						<div class="info">
	 							<span><?php echo date('Y'), $posts['created_at']; ?></span>
					<span class="read_more">Read more...</span>

	 						</div>
	 					</div>
	 				</a>
	 			</div>
	 		<?php endforeach; ?>
	 	</div>
	 	<!--footer -->
	 	<?php include (ROOT_PATH. '/includes/footer.php'); ?>
	 	</div>
	 </div>
</body>
</html>