<div class="footer">
	 		<p>@copy <?php echo date('D:M:Y'); ?> | Kaugi blog </p> 
	 	</div>