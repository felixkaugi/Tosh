<!DOCTYPE html>
<html>
<head>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Averia+Serif+Libre|Noto+Serif|Tangerine" rel="stylesheet">
	<!-- Styling for public area -->
	<link rel="stylesheet" type="text/css" href="static/css/public_styling.css">
	<meta charset="UTF-8">