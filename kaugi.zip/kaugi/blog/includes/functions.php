<?php
include_once 'config.php';
function getPublishedPost(){
	global $con;
	$sql = "SELECT * FROM posts WHERE published=true";
	$query = mysqli_query($con, $sql);
//fetching an associative array
	$posts = mysqli_fetch_all($query, MYSQLI_ASSOC);
	
return $posts;
 }
	/*$final_post = array();
	foreach ($posts as $post) {
		$post['topic'] = getPostTopics($post['id']);
        array_push($final_post, $post);
        return $final_post;
	}*/
	
	//* Receives a post id and
//* Returns topic of the post
function getPostTopics($post_id){
	global $con;
	$sql = "SELECT * FROM topics WHERE id =(SELECT topic_id FROM post_topics WHERE post_id=$post_id) LIMIT =1";
	$results = mysqli_query($con, $sql);
	$topics= mysqli_fetch_assoc($results);
	return $topics;
}

 
?>
 
