<div class="banner">
  <div class="welcome_msg">
  	<h1>Inspiration of the day</h1>
  	<p>
  		Even if Jesus was <br>
  		born in a major <br>
  		he didn't become a cow
  	</p>
  	<a href="register.php" class="btn">Join Us!</a>
  </div>
  <div class="login_div">
  	<form action="index.php" method="post">
  		<h2>LogIn</h2>
  		<input type="text" name="username" placeholder="Username">
  		<input type="password" name="password" placeholder="Password">
  		<button class="btn" type="submit" name="login_btn">Sign In</button>
  	</form>
  </div>	
</div>